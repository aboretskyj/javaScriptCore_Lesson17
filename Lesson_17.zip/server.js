var express = require("express");
var bodyParser = require("body-parser");

var server = express();
var jsonParser = bodyParser.json();

server.use(express.static(__dirname));
server.use(jsonParser);

server.get("/", function(request, response){
    console.log("server is started");
    response.send("<h1>Hello!</h1>");
});

server.get("/user-data", function(request,response){
    console.log(request.query);

    var obj = request.query;
    obj.userEmail = obj.userName + obj.userSurname + "@gmail.com"

    // response.send(JSON.stringify(request.query));
    response.send(JSON.stringify( obj.userEmail));
});


server.listen(3001);