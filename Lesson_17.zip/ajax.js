function getUserInfo(){
    var userName = document.getElementById("userNameFieldGet").value.toLowerCase();
    var userSurname = document.getElementById("userSurameFieldGet").value.toLowerCase();

    var url = '/user-data?userName='+userName+'&userSurname='+userSurname;

    getGeneratedEmail(url).then(
    function(response){
        alert(response);
    },
    function(error){
        alert(error);
    });
};

function getGeneratedEmail(url){
    return new Promise (function (resolve, reject){
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);

        xhr.onload =function(){
            if (this.status == 200){
                resolve(this.response);
            } else {
                var err = new Error(this.statusText);
                err.code = this.status;
                reject(err);
            };
        };
        
        xhr.send();
    })
}



